@echo off
title Maa Kitchen Preview Server
echo ========================================================
echo   Starting Maa Kitchen Website Preview
echo ========================================================
echo.
echo Opening website in your default browser...
start "" "%~dp0index.html"
echo.
echo If you prefer a local HTTP server on port 8080:
echo Close this window whenever you want to stop the server.
echo.
python -m http.server 8080
pause
