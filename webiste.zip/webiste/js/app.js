/**
 * Maa Kitchen - Main Application Controller
 * Handles UI interactions, data binding, animations, and gallery rendering.
 */

document.addEventListener('DOMContentLoaded', () => {
  const data = window.RESTAURANT_DATA;
  if (!data) return;

  // ------------------------------------------------------------------------
  // 1. Data Binding & Content Initialization
  // ------------------------------------------------------------------------
  initContentBinding(data);
  initGallery(data);
  initReviews(data);

  // ------------------------------------------------------------------------
  // 2. Navigation & Sticky Header
  // ------------------------------------------------------------------------
  initNavigation();

  // ------------------------------------------------------------------------
  // 3. Animated Trust Counter
  // ------------------------------------------------------------------------
  initRatingCounter(data);

  // ------------------------------------------------------------------------
  // 4. Utility Actions (Copy Address, Back to Top, Toast)
  // ------------------------------------------------------------------------
  initUtilities(data);
});

/**
 * Binds central data to DOM elements
 */
function initContentBinding(data) {
  // Brand name & location tags
  document.querySelectorAll('.js-brand-name').forEach(el => el.textContent = data.identity.name);
  document.querySelectorAll('.js-location-area').forEach(el => el.textContent = `${data.location.area}, ${data.location.locality}`);
  document.querySelectorAll('.js-full-address').forEach(el => el.textContent = data.location.fullAddress);

  // Google Maps and Directions Links
  document.querySelectorAll('.js-directions-link').forEach(el => {
    el.href = data.location.directionsUrl;
    el.setAttribute('target', '_blank');
    el.setAttribute('rel', 'noopener noreferrer');
  });

  document.querySelectorAll('.js-maps-link').forEach(el => {
    el.href = data.location.googleMapsUrl;
    el.setAttribute('target', '_blank');
    el.setAttribute('rel', 'noopener noreferrer');
  });

  // Phone Links
  document.querySelectorAll('.js-phone-link').forEach(el => {
    if (data.contact.isAvailable && data.contact.phone) {
      el.href = `tel:${data.contact.phone}`;
      el.textContent = data.contact.phone;
    } else {
      el.href = data.location.directionsUrl; // fallback to visiting in person
      el.setAttribute('title', data.contact.phoneDisplay);
    }
  });

  // Hours & Status
  const hoursDisplay = document.getElementById('display-hours-text');
  if (hoursDisplay) {
    hoursDisplay.textContent = data.hours.displaySummary;
  }
}

/**
 * Initializes Masonry Photo Gallery and Lightbox integration
 */
function initGallery(data) {
  const galleryGrid = document.getElementById('gallery-grid');
  if (!galleryGrid || !data.gallery) return;

  galleryGrid.innerHTML = '';
  data.gallery.forEach((item, index) => {
    const el = document.createElement('div');
    el.className = `gallery-item span-${item.span || 'square'}`;
    el.setAttribute('role', 'button');
    el.setAttribute('tabindex', '0');
    el.setAttribute('aria-label', `View ${item.title}`);

    el.innerHTML = `
      <img src="${item.url}" alt="${item.title}" loading="lazy" />
      <div class="gallery-item-overlay">
        <span class="gallery-item-tag">${item.categoryLabel}</span>
        <h4 class="gallery-item-title">${item.title}</h4>
      </div>
    `;

    const openInLightbox = () => {
      if (window.lightboxInstance) {
        window.lightboxInstance.open(data.gallery, index);
      }
    };

    el.addEventListener('click', openInLightbox);
    el.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        openInLightbox();
      }
    });

    galleryGrid.appendChild(el);
  });
}

/**
 * Initializes Reviews or elegant Google Maps sync notice
 */
function initReviews(data) {
  const reviewsContainer = document.getElementById('reviews-container');
  if (!reviewsContainer) return;

  if (data.reviews.isAvailable && data.reviews.items && data.reviews.items.length > 0) {
    reviewsContainer.innerHTML = '<div class="reviews-grid"></div>';
    const grid = reviewsContainer.querySelector('.reviews-grid');
    data.reviews.items.forEach(rev => {
      const card = document.createElement('article');
      card.className = 'review-card';
      card.innerHTML = `
        <span class="review-quote-mark">“</span>
        <div>
          <div class="review-stars">
            ${'<svg viewBox="0 0 24 24"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>'.repeat(rev.rating || 5)}
          </div>
          <p class="review-text">"${rev.text}"</p>
        </div>
        <div class="review-author-row">
          <div class="author-avatar">${rev.author.charAt(0)}</div>
          <div>
            <div class="author-name">${rev.author}</div>
            <div class="author-meta">
              <span class="google-review-badge">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14h2v2h-2zm0-10h2v8h-2z"/></svg>
                Google Maps Review
              </span>
              <span>•</span>
              <span>${rev.date || 'Verified Diner'}</span>
            </div>
          </div>
        </div>
      `;
      grid.appendChild(card);
    });
  } else {
    // Respect "DO NOT INVENT" rule: show verified invitation to check Google Maps reviews
    reviewsContainer.innerHTML = `
      <div class="reviews-placeholder-box">
        <div class="reviews-placeholder-icon">
          <svg fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/>
          </svg>
        </div>
        <h3 class="reviews-placeholder-title">Live Google Reviews Integration</h3>
        <p class="reviews-placeholder-text">
          Customer reviews and ratings are synced directly with our official Google Maps profile. To read verified diner experiences, photos, and ratings from our guests in Chintalkunta, visit our Google listing.
        </p>
        <a href="${data.location.googleMapsUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-secondary">
          <svg fill="currentColor" viewBox="0 0 24 24" width="18" height="18">
            <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
          </svg>
          Read Reviews on Google Maps
        </a>
      </div>
    `;
  }
}

/**
 * Sticky Navbar, Active link spy, and Mobile Drawer
 */
function initNavigation() {
  const header = document.querySelector('.site-header');
  const hamburger = document.getElementById('hamburger-btn');
  const drawer = document.getElementById('mobile-drawer');
  const backdrop = document.getElementById('mobile-drawer-backdrop');
  const drawerClose = document.getElementById('drawer-close-btn');
  const drawerLinks = document.querySelectorAll('.drawer-nav-link');

  // Scroll effect for header
  const handleScroll = () => {
    if (window.scrollY > 40) {
      header?.classList.add('scrolled');
    } else {
      header?.classList.remove('scrolled');
    }
  };
  window.addEventListener('scroll', handleScroll, { passive: true });
  handleScroll();

  // Mobile Drawer Toggle
  const openDrawer = () => {
    drawer?.classList.add('active');
    backdrop?.classList.add('active');
    document.body.style.overflow = 'hidden';
  };

  const closeDrawer = () => {
    drawer?.classList.remove('active');
    backdrop?.classList.remove('active');
    document.body.style.overflow = '';
  };

  hamburger?.addEventListener('click', openDrawer);
  drawerClose?.addEventListener('click', closeDrawer);
  backdrop?.addEventListener('click', closeDrawer);

  drawerLinks.forEach(link => {
    link.addEventListener('click', closeDrawer);
  });

  // ScrollSpy for Nav Links
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link');

  window.addEventListener('scroll', () => {
    const scrollPos = window.scrollY + 120;
    sections.forEach(sec => {
      const top = sec.offsetTop;
      const height = sec.offsetHeight;
      const id = sec.getAttribute('id');
      if (scrollPos >= top && scrollPos < top + height) {
        navLinks.forEach(l => {
          l.classList.toggle('active', l.getAttribute('href') === `#${id}`);
        });
      }
    });
  }, { passive: true });
}

/**
 * Animated Rating Counter when scrolled into view
 */
function initRatingCounter(data) {
  const counterEl = document.getElementById('counter-rating');
  const reviewCountEl = document.getElementById('counter-reviews');
  if (!counterEl) return;

  let hasAnimated = false;
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting && !hasAnimated) {
        hasAnimated = true;
        animateNumber(counterEl, 0, data.metrics.rating || 4.8, 1400, 1);
        if (reviewCountEl) {
          animateNumber(reviewCountEl, 0, 100, 1400, 0, '+');
        }
      }
    });
  }, { threshold: 0.3 });

  observer.observe(counterEl);
}

function animateNumber(element, start, end, duration, decimals = 0, suffix = '') {
  let startTime = null;
  const step = (timestamp) => {
    if (!startTime) startTime = timestamp;
    const progress = Math.min((timestamp - startTime) / duration, 1);
    const current = start + progress * (end - start);
    element.textContent = current.toFixed(decimals) + suffix;
    if (progress < 1) {
      window.requestAnimationFrame(step);
    }
  };
  window.requestAnimationFrame(step);
}

/**
 * Copy Address, Back to Top, and Toast Notifications
 */
function initUtilities(data) {
  // Copy Address Button
  const copyBtn = document.getElementById('copy-address-btn');
  copyBtn?.addEventListener('click', () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(data.location.fullAddress).then(() => {
        showToast('Address copied to clipboard!');
      }).catch(() => {
        showToast('Could not copy address automatically.');
      });
    } else {
      showToast(data.location.fullAddress);
    }
  });

  // Back to Top Button
  const backToTop = document.getElementById('back-to-top');
  window.addEventListener('scroll', () => {
    if (window.scrollY > 400) {
      backToTop?.classList.add('visible');
    } else {
      backToTop?.classList.remove('visible');
    }
  }, { passive: true });

  backToTop?.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

function showToast(message) {
  let toast = document.getElementById('app-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'app-toast';
    toast.className = 'toast-notice';
    document.body.appendChild(toast);
  }
  toast.innerHTML = `
    <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
      <polyline points="20 6 9 17 4 12"></polyline>
    </svg>
    <span>${message}</span>
  `;
  toast.classList.add('show');
  setTimeout(() => {
    toast.classList.remove('show');
  }, 3000);
}
