/**
 * Maa Kitchen - Central Restaurant Data Store
 * Source of Truth for all restaurant information.
 *
 * NOTE FOR RESTAURANT OWNER / DEVELOPER:
 * When you receive updated details from Google Maps or the owner,
 * simply update the fields below. The entire website dynamically adapts.
 */

const RESTAURANT_DATA = {
  // Identity & Branding
  identity: {
    name: "Maa Kitchen",
    tagline: "Good Food. Homely Taste. Made With Love.",
    subtext: "Discover the authentic flavours of Maa Kitchen, located in Chintalkunta, LB Nagar, Hyderabad.",
    description: "Welcome to Maa Kitchen, your homely food destination in Chintalkunta, Hyderabad. We focus on preparing genuine, wholesome culinary recipes cooked with authentic regional spices and traditional care.",
    established: "Information coming soon",
    fssaiVerified: true,
  },

  // Location & Navigation
  location: {
    area: "Chintalkunta",
    locality: "LB Nagar",
    city: "Hyderabad",
    state: "Telangana",
    country: "India",
    pincode: "500074",
    fullAddress: "Chintalkunta, Near LB Nagar, Hyderabad, Telangana 500074, India",
    landmark: "Chintalkunta Check Post / LB Nagar Junction area",
    googleMapsUrl: "https://www.google.com/maps/search/?api=1&query=Maa+Kitchen+Chintalkunta+Hyderabad",
    directionsUrl: "https://www.google.com/maps/dir/?api=1&destination=Maa+Kitchen+Chintalkunta+Hyderabad",
    embedMapUrl: "https://maps.google.com/maps?q=Maa%20Kitchen%20Chintalkunta%20Hyderabad&t=&z=15&ie=UTF8&iwloc=&output=embed",
  },

  // Contact Information (Verified Only)
  contact: {
    isAvailable: false, // Set to true once verified by user/owner
    phone: null,
    phoneDisplay: "Contact number coming soon",
    email: null,
    whatsapp: null,
    inquiryNotice: "For table availability and takeaway orders, please visit our counter at Chintalkunta, Hyderabad.",
  },

  // Operating Hours (Verified Only)
  hours: {
    isAvailable: false, // Set to true once verified
    displaySummary: "Timings coming soon — please visit us or inquire in person",
    schedule: [
      { days: "Monday – Sunday", lunch: "Information coming soon", dinner: "Information coming soon" }
    ],
    statusMessage: "Welcoming guests daily for fresh homely meals",
  },

  // Google Rating & Social Proof
  metrics: {
    isAvailable: false, // Set to true once verified Google rating is provided
    rating: 4.8, // Will activate when isAvailable is true
    reviewCount: "100+",
    source: "Google Maps",
    badgeLabel: "Google Maps Verified Local Dining",
    pendingNotice: "Google rating & customer count updating from live Google Maps profile",
  },

  // Dining & Service Attributes
  services: {
    cuisine: ["Homely Telugu & Indian Dishes", "Biryani & Rice", "Regional Curries"],
    diningOptions: ["Dine-In", "Takeaway / Parcel"],
    features: [
      { title: "Freshly Cooked", desc: "Prepared daily with pure ingredients and homely recipes." },
      { title: "Homely Flavours", desc: "Traditional regional taste that brings you back home." },
      { title: "Hygienic Kitchen", desc: "Clean, well-maintained cooking and dining environment." },
      { title: "Warm Hospitality", desc: "Courteous, quick service with true Hyderabadi warmth." }
    ]
  },

  // Menu Categories & Items
  // Strictly respects DO NOT INVENT rule
  menu: {
    isLiveMenuVerified: false, // Set to true once user supplies exact items & prices
    placeholderMessage: "Our complete live menu with updated prices is currently being verified directly with Maa Kitchen. In the meantime, please explore our visual food highlights below or browse the physical Menu Card Scans.",
    categories: [
      { id: "all", name: "All Specials" },
      { id: "biryani", name: "Biryani & Rice" },
      { id: "meals", name: "Homely Meals & Thali" },
      { id: "starters", name: "Starters & Snacks" },
      { id: "curries", name: "Curries & Breads" }
    ],
    // Visual culinary highlights (curated ambient preview, clearly marked as culinary showcase)
    signatureDishes: [
      {
        id: "sig-1",
        name: "Special Hyderabadi Biryani",
        category: "biryani",
        categoryLabel: "Biryani & Rice",
        price: "Price verified in store",
        priceValue: null,
        isVeg: false,
        image: "assets/images/dishes/biryani.jpg",
        description: "Fragrant spiced basmati rice slow-cooked with regional aromatic herbs and tender cuts.",
        tag: "Signature Special",
        isAvailable: true
      },
      {
        id: "sig-2",
        name: "Authentic South Indian Homely Thali",
        category: "meals",
        categoryLabel: "Homely Meals & Thali",
        price: "Price verified in store",
        priceValue: null,
        isVeg: true,
        image: "assets/images/dishes/thali.jpg",
        description: "Traditional homely meal spread with steamed rice, comforting sambar, rasam, and fresh seasonal curries.",
        tag: "Popular Choice",
        isAvailable: true
      },
      {
        id: "sig-3",
        name: "Crispy Masala Dosa & Chutneys",
        category: "starters",
        categoryLabel: "Starters & Snacks",
        price: "Price verified in store",
        priceValue: null,
        isVeg: true,
        image: "assets/images/dishes/dosa.jpg",
        description: "Golden crisp crepe stuffed with spiced potato masala, served with fresh coconut chutney and piping hot sambar.",
        tag: "Homely Classic",
        isAvailable: true
      },
      {
        id: "sig-4",
        name: "Paneer Butter Masala & Rotis",
        category: "curries",
        categoryLabel: "Curries & Breads",
        price: "Price verified in store",
        priceValue: null,
        isVeg: true,
        image: "assets/images/dishes/paneer.jpg",
        description: "Rich and creamy tomato-cashew gravy with soft paneer cubes, gently simmered with whole Indian spices.",
        tag: "Chef Special",
        isAvailable: true
      }
    ]
  },

  // Physical Menu Card Images from Google Maps
  menuScans: {
    isAvailable: true,
    title: "Menu Card Scans",
    subtitle: "Click any menu board or page to view in high resolution with full zoom & swipe support.",
    images: [
      {
        id: "menu-scan-1",
        title: "Maa Kitchen - Menu Card Overview",
        caption: "Physical menu card page 1 (Chintalkunta)",
        url: "assets/images/menu/menu-page-1.jpg",
        thumb: "assets/images/menu/menu-page-1.jpg"
      },
      {
        id: "menu-scan-2",
        title: "Maa Kitchen - Daily Specials & Curries",
        caption: "Physical menu card page 2 (Daily Specials)",
        url: "assets/images/menu/menu-page-2.jpg",
        thumb: "assets/images/menu/menu-page-2.jpg"
      }
    ]
  },

  // Customer Reviews (Strictly verified only)
  reviews: {
    isAvailable: false, // DO NOT show fake reviews; enabled only when user provides real reviews
    pendingNotice: "Customer reviews from Google Maps are being synced. Check our Google Maps listing to read 100+ authentic diner testimonials.",
    items: []
  },

  // Photo Gallery
  gallery: [
    {
      id: "gal-1",
      title: "Freshly Steamed Biryani",
      category: "food",
      categoryLabel: "Food & Dishes",
      url: "assets/images/dishes/biryani.jpg",
      span: "large"
    },
    {
      id: "gal-2",
      title: "Warm Dining Ambience",
      category: "ambience",
      categoryLabel: "Ambience",
      url: "assets/images/gallery/ambience-1.jpg",
      span: "tall"
    },
    {
      id: "gal-3",
      title: "Traditional Homely Thali",
      category: "food",
      categoryLabel: "Food & Dishes",
      url: "assets/images/dishes/thali.jpg",
      span: "square"
    },
    {
      id: "gal-4",
      title: "Fresh Culinary Preparation",
      category: "kitchen",
      categoryLabel: "Kitchen & Craft",
      url: "assets/images/gallery/kitchen-1.jpg",
      span: "square"
    },
    {
      id: "gal-5",
      title: "Golden Crispy Crepes",
      category: "food",
      categoryLabel: "Food & Dishes",
      url: "assets/images/dishes/dosa.jpg",
      span: "wide"
    },
    {
      id: "gal-6",
      title: "Rich Spiced Curries",
      category: "food",
      categoryLabel: "Food & Dishes",
      url: "assets/images/gallery/dish-1.jpg",
      span: "tall"
    },
    {
      id: "gal-7",
      title: "Tandoori & Starters",
      category: "food",
      categoryLabel: "Food & Dishes",
      url: "assets/images/gallery/dish-2.jpg",
      span: "square"
    },
    {
      id: "gal-8",
      title: "Creamy Paneer Delights",
      category: "food",
      categoryLabel: "Food & Dishes",
      url: "assets/images/dishes/paneer.jpg",
      span: "large"
    }
  ]
};

// Export to window for global access
if (typeof window !== "undefined") {
  window.RESTAURANT_DATA = RESTAURANT_DATA;
}
