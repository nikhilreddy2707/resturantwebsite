/**
 * Maa Kitchen - Interactive Digital Menu Controller
 * Handles dynamic category tabs, real-time search, veg/non-veg filter, and menu scans.
 */

document.addEventListener('DOMContentLoaded', () => {
  const data = window.RESTAURANT_DATA;
  if (!data) return;

  const categoryTabsContainer = document.getElementById('menu-category-tabs');
  const dishGrid = document.getElementById('signature-dish-grid');
  const searchInput = document.getElementById('menu-search-input');
  const dietButtons = document.querySelectorAll('.diet-toggle-btn');
  const menuNoticeText = document.getElementById('menu-notice-text');
  const menuScansGrid = document.getElementById('menu-scans-grid');

  let activeCategory = 'all';
  let activeDiet = 'all'; // 'all' | 'veg' | 'nonveg'
  let searchQuery = '';

  // 1. Initialize Notice
  if (menuNoticeText && data.menu.placeholderMessage) {
    menuNoticeText.textContent = data.menu.placeholderMessage;
  }

  // 2. Render Category Tabs
  if (categoryTabsContainer && data.menu.categories) {
    categoryTabsContainer.innerHTML = '';
    data.menu.categories.forEach(cat => {
      const btn = document.createElement('button');
      btn.className = `category-tab ${cat.id === activeCategory ? 'active' : ''}`;
      btn.textContent = cat.name;
      btn.dataset.category = cat.id;

      btn.addEventListener('click', () => {
        document.querySelectorAll('.category-tab').forEach(t => t.classList.remove('active'));
        btn.classList.add('active');
        activeCategory = cat.id;
        filterAndRenderDishes();
      });

      categoryTabsContainer.appendChild(btn);
    });
  }

  // 3. Render Menu Card Scans (Physical Google Maps menu boards/pages)
  if (menuScansGrid && data.menuScans && data.menuScans.images) {
    menuScansGrid.innerHTML = '';
    data.menuScans.images.forEach((scan, index) => {
      const card = document.createElement('article');
      card.className = 'menu-scan-card';
      card.setAttribute('role', 'button');
      card.setAttribute('tabindex', '0');
      card.setAttribute('aria-label', `View ${scan.title}`);

      card.innerHTML = `
        <div class="menu-scan-thumbnail">
          <img src="${scan.thumb}" alt="${scan.title}" loading="lazy" />
          <div class="scan-overlay-prompt">
            <div class="scan-zoom-icon-circle">
              <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <circle cx="11" cy="11" r="8"></circle>
                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                <line x1="11" y1="8" x2="11" y2="14"></line>
                <line x1="8" y1="11" x2="14" y2="11"></line>
              </svg>
            </div>
            <span style="font-weight:700;font-size:0.9rem;">Click to View & Zoom</span>
          </div>
        </div>
        <div class="scan-card-body">
          <h3 class="scan-card-title">${scan.title}</h3>
          <p class="scan-card-caption">${scan.caption}</p>
        </div>
      `;

      const launchModal = () => {
        if (window.lightboxInstance) {
          window.lightboxInstance.open(data.menuScans.images, index);
        }
      };

      card.addEventListener('click', launchModal);
      card.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          launchModal();
        }
      });

      menuScansGrid.appendChild(card);
    });
  }

  // 4. Render Dishes based on active category, diet, and search filter
  function filterAndRenderDishes() {
    if (!dishGrid) return;

    const dishes = data.menu.signatureDishes || [];
    const query = searchQuery.trim().toLowerCase();

    const filtered = dishes.filter(dish => {
      // Category filter
      const matchesCategory = activeCategory === 'all' || dish.category === activeCategory;

      // Dietary filter
      const matchesDiet = 
        activeDiet === 'all' ? true :
        activeDiet === 'veg' ? dish.isVeg === true :
        dish.isVeg === false;

      // Search query
      const matchesSearch = 
        !query || 
        dish.name.toLowerCase().includes(query) || 
        (dish.description && dish.description.toLowerCase().includes(query)) ||
        (dish.categoryLabel && dish.categoryLabel.toLowerCase().includes(query));

      return matchesCategory && matchesDiet && matchesSearch;
    });

    if (filtered.length === 0) {
      dishGrid.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 48px 24px; background: #fff; border-radius: 16px; border: 1px dashed var(--border-light);">
          <div style="width: 48px; height: 48px; margin: 0 auto 16px auto; color: var(--gold-600);">
            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <circle cx="11" cy="11" r="8"></circle>
              <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
            </svg>
          </div>
          <h3 style="font-family: var(--font-serif); font-size: 1.3rem; margin-bottom: 8px;">No matching dishes found</h3>
          <p style="color: var(--text-secondary); font-size: 0.95rem; max-width: 420px; margin: 0 auto 16px auto;">
            Try selecting a different category or clearing your search filters to explore our culinary offerings.
          </p>
          <button class="btn btn-primary btn-sm" id="reset-filters-btn">Reset All Filters</button>
        </div>
      `;

      document.getElementById('reset-filters-btn')?.addEventListener('click', () => {
        activeCategory = 'all';
        activeDiet = 'all';
        searchQuery = '';
        if (searchInput) searchInput.value = '';
        document.querySelectorAll('.category-tab').forEach(t => {
          t.classList.toggle('active', t.dataset.category === 'all');
        });
        dietButtons.forEach(b => {
          b.classList.toggle('active', b.dataset.diet === 'all');
        });
        filterAndRenderDishes();
      });
      return;
    }

    dishGrid.innerHTML = '';
    filtered.forEach(dish => {
      const card = document.createElement('article');
      card.className = 'dish-card';

      const dietClass = dish.isVeg ? 'veg' : 'nonveg';
      const dietTitle = dish.isVeg ? 'Vegetarian' : 'Non-Vegetarian';

      card.innerHTML = `
        <div class="dish-image-box">
          <img src="${dish.image}" alt="${dish.name}" class="dish-img" loading="lazy" />
          <span class="dish-category-badge">${dish.categoryLabel}</span>
          <div class="dish-diet-badge" title="${dietTitle}">
            <span class="fssai-indicator ${dietClass}"></span>
          </div>
        </div>
        <div class="dish-body">
          <div class="dish-header">
            <h3 class="dish-title">${dish.name}</h3>
            <span class="dish-price">${dish.price}</span>
          </div>
          <p class="dish-description">${dish.description || 'Prepared fresh with authentic regional spices.'}</p>
          <div class="dish-footer">
            <span class="dish-tag">${dish.tag || 'House Specialty'}</span>
            <span style="font-size:0.75rem; color: var(--text-muted);">Maa Kitchen Special</span>
          </div>
        </div>
      `;

      dishGrid.appendChild(card);
    });
  }

  // 5. Search input event
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      searchQuery = e.target.value;
      filterAndRenderDishes();
    });
  }

  // 6. Dietary filter buttons
  dietButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      dietButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeDiet = btn.dataset.diet;
      filterAndRenderDishes();
    });
  });

  // Initial render
  filterAndRenderDishes();
});
