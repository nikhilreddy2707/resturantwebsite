/**
 * Maa Kitchen - Fullscreen Image Lightbox & Zoom Viewer
 * Supports Gallery & Menu Scans, keyboard navigation, zoom, and mobile touch swiping.
 */

class LightboxViewer {
  constructor() {
    this.modal = document.getElementById('lightbox-modal');
    this.image = document.getElementById('lightbox-image');
    this.title = document.getElementById('lightbox-title');
    this.counter = document.getElementById('lightbox-counter');
    this.prevBtn = document.getElementById('lightbox-prev');
    this.nextBtn = document.getElementById('lightbox-next');
    this.closeBtn = document.getElementById('lightbox-close');
    this.zoomBtn = document.getElementById('lightbox-zoom');

    this.items = [];
    this.currentIndex = 0;
    this.isZoomed = false;
    this.touchStartX = 0;
    this.touchEndX = 0;

    this.initEvents();
  }

  initEvents() {
    if (!this.modal) return;

    // Close button
    this.closeBtn?.addEventListener('click', () => this.close());

    // Navigation buttons
    this.prevBtn?.addEventListener('click', () => this.prev());
    this.nextBtn?.addEventListener('click', () => this.next());

    // Zoom button
    this.zoomBtn?.addEventListener('click', () => this.toggleZoom());

    // Image click to toggle zoom
    this.image?.addEventListener('click', () => this.toggleZoom());

    // Backdrop click to close (if not clicking image or controls)
    this.modal.addEventListener('click', (e) => {
      if (e.target === this.modal || e.target.classList.contains('lightbox-viewport')) {
        this.close();
      }
    });

    // Keyboard navigation
    window.addEventListener('keydown', (e) => {
      if (!this.isOpen()) return;
      if (e.key === 'Escape') this.close();
      if (e.key === 'ArrowLeft') this.prev();
      if (e.key === 'ArrowRight') this.next();
    });

    // Touch swipe support for mobile
    const viewport = this.modal.querySelector('.lightbox-viewport');
    if (viewport) {
      viewport.addEventListener('touchstart', (e) => {
        this.touchStartX = e.changedTouches[0].screenX;
      }, { passive: true });

      viewport.addEventListener('touchend', (e) => {
        this.touchEndX = e.changedTouches[0].screenX;
        this.handleSwipe();
      }, { passive: true });
    }
  }

  handleSwipe() {
    const swipeThreshold = 50;
    const diff = this.touchStartX - this.touchEndX;
    if (Math.abs(diff) > swipeThreshold) {
      if (diff > 0) {
        // Swiped left -> Next image
        this.next();
      } else {
        // Swiped right -> Previous image
        this.prev();
      }
    }
  }

  isOpen() {
    return this.modal && this.modal.classList.contains('active');
  }

  open(items, startIndex = 0) {
    if (!items || !items.length) return;
    this.items = items;
    this.currentIndex = Math.max(0, Math.min(startIndex, items.length - 1));
    this.resetZoom();
    this.updateContent();

    this.modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  close() {
    this.modal.classList.remove('active');
    document.body.style.overflow = '';
    this.resetZoom();
  }

  updateContent() {
    const item = this.items[this.currentIndex];
    if (!item) return;

    this.resetZoom();
    this.image.src = item.url;
    this.image.alt = item.title || 'Maa Kitchen Photograph';
    this.title.textContent = item.title || (item.caption || 'Maa Kitchen Gallery');
    this.counter.textContent = `${this.currentIndex + 1} of ${this.items.length}`;

    // Update button states
    if (this.prevBtn) this.prevBtn.style.display = this.items.length > 1 ? 'flex' : 'none';
    if (this.nextBtn) this.nextBtn.style.display = this.items.length > 1 ? 'flex' : 'none';
  }

  next() {
    if (this.items.length <= 1) return;
    this.currentIndex = (this.currentIndex + 1) % this.items.length;
    this.updateContent();
  }

  prev() {
    if (this.items.length <= 1) return;
    this.currentIndex = (this.currentIndex - 1 + this.items.length) % this.items.length;
    this.updateContent();
  }

  toggleZoom() {
    this.isZoomed = !this.isZoomed;
    if (this.isZoomed) {
      this.image.style.transform = 'scale(1.7)';
      this.image.classList.add('zoomed');
    } else {
      this.resetZoom();
    }
  }

  resetZoom() {
    this.isZoomed = false;
    if (this.image) {
      this.image.style.transform = 'scale(1)';
      this.image.classList.remove('zoomed');
    }
  }
}

// Instantiate and expose globally
window.addEventListener('DOMContentLoaded', () => {
  window.lightboxInstance = new LightboxViewer();
});
